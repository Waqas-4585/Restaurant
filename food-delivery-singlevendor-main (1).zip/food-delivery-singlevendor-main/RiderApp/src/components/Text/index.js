import TextDefault from './TextDefault/TextDefault'
import TextError from './TextError/TextError'

export { TextDefault, TextError }
