export const fontStyles = {
  PoppinLight: 'Poppin300',
  PoppingRegular: 'Poppin400',
  PoppingMedium: 'Poppin500',
  PoppingSemiBold: 'Poppin600',
  PoppinBold: 'Poppin700'
}
